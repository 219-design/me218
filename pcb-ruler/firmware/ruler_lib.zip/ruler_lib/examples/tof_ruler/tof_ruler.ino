/**
 ******************************************************************************
 * @file    VL53L4CX_Sat_HelloWorld.ino
 * @author  SRA
 * @version V1.0.0
 * @date    16 March 2022
 * @brief   Arduino test application for the STMicrolectronics VL53L4CX
 *          proximity sensor satellite based on FlightSense.
 *          This application makes use of C++ classes obtained from the C
 *          components' drivers.
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; COPYRIGHT(c) 2022 STMicroelectronics</center></h2>
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *   1. Redistributions of source code must retain the above copyright notice,
 *      this list of conditions and the following disclaimer.
 *   2. Redistributions in binary form must reproduce the above copyright notice,
 *      this list of conditions and the following disclaimer in the documentation
 *      and/or other materials provided with the distribution.
 *   3. Neither the name of STMicroelectronics nor the names of its contributors
 *      may be used to endorse or promote products derived from this software
 *      without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 */
/*
 * To use this sketch you need to connect the VL53L4CD satellite sensor directly to the Nucleo board with wires in this way:
 * pin 1 (GND) of the VL53L4CD satellite connected to GND of the Nucleo board
 * pin 2 (VDD) of the VL53L4CD satellite connected to 3V3 pin of the Nucleo board
 * pin 3 (SCL) of the VL53L4CD satellite connected to pin D15 (SCL) of the Nucleo board
 * pin 4 (SDA) of the VL53L4CD satellite connected to pin D14 (SDA) of the Nucleo board
 * pin 5 (GPIO1) of the VL53L4CD satellite connected to pin A2 of the Nucleo board
 * pin 6 (XSHUT) of the VL53L4CD satellite connected to pin A1 of the Nucleo board
 */
/* Includes ------------------------------------------------------------------*/
#include <Arduino.h>
#include <Wire.h>
#include <vl53l4cx_class.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <assert.h>
#include <stdlib.h>

#include <RulerButtons.h>
// #include <RulerPixels.h>
#include <ruler.h>

#include "Wire.h"
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
// https://github.com/adafruit/Adafruit_SSD1306

#define DEV_I2C Wire
#define SerialPort Serial

#ifndef LED_BUILTIN
  #define LED_BUILTIN 13
#endif
#define LedPin LED_BUILTIN

// Components.
VL53L4CX sensor_vl53l4cx_sat(&DEV_I2C, A1);

bool m_use_metric = true;

constexpr uint8_t kDisplayWidth{128};
constexpr uint8_t kDisplayHeight{64};
constexpr int8_t kOledReset{-1}; // No Reset Pin

Adafruit_SSD1306 display(kDisplayWidth, kDisplayHeight, &Wire, kOledReset);

void display_dist(uint32_t dist_mm){
    // Clear the buffer
  display.clearDisplay();
  // Set text color to white
  display.setTextColor(SSD1306_WHITE); 
  // Set cursor position (column, row)

  display.setCursor(0, 20); 
 // Set text size
  display.setTextSize(2); 
  // Print text
  display.printf("TOF Ruler\r\n");

  if(dist_mm <20){
    display.printf("TOO CLOSE!\r\n");
  } else {
    if(m_use_metric){
      display.printf("%4d mm\r\n", dist_mm);
    } else {
      display.printf("%4.3f in\r\n", dist_mm/25.4f);
    }
  }

  display.display();
}

// const char* c_btn_name[NUM_BTNS] = {
//   [UP_BTN_IDX] = "UP",
//   [DOWN_BTN_IDX] = "DOWN",
//   [LEFT_BTN_IDX] = "LEFT",
//   [RIGHT_BTN_IDX] = "RIGHT",
//   [CENTER_BTN_IDX] = "CENTER",
// };

// static Pixels pixels = Pixels();

static Buttons buttons = Buttons();


// #define UP_PIXEL_COLOR (Adafruit_NeoPixel::Color(128, 0, 0))          //red
// #define DOWN_PIXEL_COLOR (Adafruit_NeoPixel::Color(128, 128, 0))      //yellow
// #define LEFT_PIXEL_COLOR (Adafruit_NeoPixel::Color(0, 128, 0))        //green
// #define RIGHT_PIXEL_COLOR (Adafruit_NeoPixel::Color(0, 0, 128))       //blue
// #define CENTER_PIXEL_COLOR (Adafruit_NeoPixel::Color(128, 128, 128))  //white

// // needs to be ordered correctly ...
// const uint32_t c_pixel_color[NUM_PIXELS] = {
//   [LEFT_PIXEL_IDX] = LEFT_PIXEL_COLOR,
//   [DOWN_PIXEL_IDX] = DOWN_PIXEL_COLOR,
//   [CENTER_PIXEL_IDX] = CENTER_PIXEL_COLOR,
//   [UP_PIXEL_IDX] = UP_PIXEL_COLOR,
//   [RIGHT_PIXEL_IDX] = RIGHT_PIXEL_COLOR,
// };

// int get_pixel_index(uint8_t button_idx) {
//   switch (button_idx) {
//     case UP_BTN_IDX:
//       return UP_PIXEL_IDX;
//     case DOWN_BTN_IDX:
//       return DOWN_PIXEL_IDX;
//     case LEFT_BTN_IDX:
//       return LEFT_PIXEL_IDX;
//     case RIGHT_BTN_IDX:
//       return RIGHT_PIXEL_IDX;
//     case CENTER_BTN_IDX:
//       return CENTER_PIXEL_IDX;
//     default:
//       return -1;
//   }
// }

// void set_btn_pixel(uint8_t btn_idx) {
//   int pixel_idx = get_pixel_index(btn_idx);
//   pixels.set_pixel(pixel_idx, c_pixel_color[pixel_idx]);
// }

/* Setup ---------------------------------------------------------------------*/

void setup()
{
   // Led.
  pinMode(LedPin, OUTPUT);

  // Initialize serial for output.
  SerialPort.begin(115200);
  SerialPort.println("Starting...");

  //  Initialize Display
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
    Serial.println(F("SSD1306 allocation failed"));
  }

  // Initialize I2C bus.
  DEV_I2C.begin();

  // Configure VL53L4CX satellite component.
  sensor_vl53l4cx_sat.begin();

  // Switch off VL53L4CX satellite component.
  sensor_vl53l4cx_sat.VL53L4CX_Off();

  //Initialize VL53L4CX satellite component.
  sensor_vl53l4cx_sat.InitSensor(0x12);

  // Start Measurements
  sensor_vl53l4cx_sat.VL53L4CX_StartMeasurement();
}

static bool last_read = false;

void check_for_unit_change(){
  uint8_t btns = buttons.get_presses();  //keep this updated
  bool center_level = (btns & CENTER_BTN_MASK) ? true : false;
  if(center_level != last_read){
    Serial.printf("center is %d\r\n", center_level);
  }

  if(!last_read && center_level){
    //toggle unit change
    m_use_metric = !m_use_metric;
  }
  //save last read
  last_read = center_level;
}

void loop()
{
  check_for_unit_change();

  VL53L4CX_MultiRangingData_t MultiRangingData;
  VL53L4CX_MultiRangingData_t *pMultiRangingData = &MultiRangingData;
  uint8_t NewDataReady = 0;
  int no_of_object_found = 0, j;
  char report[64];
  int status;

  do {
    status = sensor_vl53l4cx_sat.VL53L4CX_GetMeasurementDataReady(&NewDataReady);
  } while (!NewDataReady);

  //Led on
  digitalWrite(LedPin, HIGH);

  if ((!status) && (NewDataReady != 0)) {
    status = sensor_vl53l4cx_sat.VL53L4CX_GetMultiRangingData(pMultiRangingData);
    no_of_object_found = pMultiRangingData->NumberOfObjectsFound;
    snprintf(report, sizeof(report), "VL53L4CX Satellite: Count=%d, #Objs=%1d ", pMultiRangingData->StreamCount, no_of_object_found);
    // SerialPort.print(report);
    for (j = 0; j < no_of_object_found; j++) {
      // if (j != 0) {
      //   SerialPort.print("\r\n                               ");
      // }
      // SerialPort.print("status=");
      // SerialPort.print(pMultiRangingData->RangeData[j].RangeStatus);
      // SerialPort.print(", D=");
      // SerialPort.print(pMultiRangingData->RangeData[j].RangeMilliMeter);
      // SerialPort.print("mm");
      // SerialPort.print(", Signal=");
      // SerialPort.print((float)pMultiRangingData->RangeData[j].SignalRateRtnMegaCps / 65536.0);
      // SerialPort.print(" Mcps, Ambient=");
      // SerialPort.print((float)pMultiRangingData->RangeData[j].AmbientRateRtnMegaCps / 65536.0);
      // SerialPort.print(" Mcps");

      if(j == 0){
        display_dist(pMultiRangingData->RangeData[j].RangeMilliMeter);
      }
    }
    // SerialPort.println("");

    if (status == 0) {
      status = sensor_vl53l4cx_sat.VL53L4CX_ClearInterruptAndStartMeasurement();
    }
  }

  digitalWrite(LedPin, LOW);
}

