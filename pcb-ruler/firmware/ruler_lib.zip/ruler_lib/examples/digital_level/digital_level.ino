#include <LSM6DS3.h>
//https://github.com/Seeed-Studio/Seeed_Arduino_LSM6DS3/

// #include <RulerButtons.h>
#include <RulerPixels.h>
#include <ruler.h>

#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
// https://github.com/adafruit/Adafruit_SSD1306

//Create a instance of class LSM6DS3
LSM6DS3 myIMU(I2C_MODE, 0x6A);  //I2C device address 0x6A

#define NEOPIXEL_PIN (0)
Pixels pixels = Pixels(NEOPIXEL_PIN);

constexpr uint8_t kDisplayWidth{ 128 };
constexpr uint8_t kDisplayHeight{ 64 };
constexpr int8_t kOledReset{ -1 };  // No Reset Pin
Adafruit_SSD1306 display(kDisplayWidth, kDisplayHeight, &Wire, kOledReset);


void display_gyro(float x, float y, float z) {
  // Clear the buffer
  display.clearDisplay();
  // Set text color to white
  display.setTextColor(SSD1306_WHITE);
  // Set cursor position (column, row)
  display.setCursor(0, 0);
  // Set text size
  display.setTextSize(1);
  display.printf("LEVEL\r\n");

  display.setCursor(0, 16);
  // Set text size
  display.setTextSize(2);
  // Print text
  display.printf("x %+3.2f\r\n", x);
  display.printf("y %+3.2f\r\n", y);
  display.printf("z %+3.2f\r\n", z);

  display.display();
}

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);

  // IMU
  if (myIMU.begin() != 0) {
    Serial.println("Device error");
  } else {
    Serial.println("Device OK!");
  }


  //  Initialize Display
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
  }
}

void loop() {
  // put your main code here, to run repeatedly:
  float x = myIMU.readFloatGyroX();
  float y = myIMU.readFloatGyroY();
  float z = myIMU.readFloatGyroZ();

  //Gyroscope
  Serial.print("\nGyroscope:\n");
  Serial.printf(" X1 = %+07.3f\r\n", x);
  Serial.printf(" Y1 = %+07.3f\r\n", y);
  Serial.printf(" Z1 = %+07.3f\r\n", z);

  display_gyro(x, y, z);
}
